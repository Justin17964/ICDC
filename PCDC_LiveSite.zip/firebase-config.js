
const firebaseConfig = {
  apiKey: "AIzaSyD4HAgURdf-4kOEziS6W8-KTOZl9_B1aG8",
  authDomain: "pcdc-2f08e.firebaseapp.com",
  projectId: "pcdc-2f08e",
  storageBucket: "pcdc-2f08e.firebasestorage.app",
  messagingSenderId: "1024625232109",
  appId: "1:1024625232109:web:7233436e3217a878cda4e4",
  measurementId: "G-3W73F5B0HZ"
};
firebase.initializeApp(firebaseConfig);
